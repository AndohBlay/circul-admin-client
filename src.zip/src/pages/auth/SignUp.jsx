import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import AuthShell from "../../components/AuthShell";
import FormField from "../../components/FormField";
import { authApi } from "../../api/auth";

const GOOGLE_AUTH_URL = `${import.meta.env.VITE_API_BASE_URL ?? ""}/auth/google/redirect`;

export default function SignUp() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "", email: "", phone: "", password: "", password_confirmation: "",
  });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState("");
  const [loading, setLoading] = useState(false);

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrors({});
    setServerError("");
    setLoading(true);
    try {
      const { data } = await authApi.register(form);
      navigate("/verify-otp", { state: { userId: data.user_id, phone: form.phone } });
    } catch (err) {
      if (err.response?.status === 422 && err.response.data?.errors) {
        setErrors(err.response.data.errors);
      } else {
        setServerError(err.response?.data?.message || "Something went wrong. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  const fieldError = (field) => errors[field]?.[0];

  return (
    <AuthShell eyebrow="Step 1 of 2" title="Create your account" subtitle="A few details to get you started.">
      {serverError && (
        <div className="mb-4 rounded-lg bg-coral/10 border border-coral/30 text-coral text-sm px-3 py-2">
          {serverError}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField label="Full name" type="text" value={form.name} onChange={update("name")} error={fieldError("name")} placeholder="Ama Owusu" required />
        <FormField label="Email" type="email" value={form.email} onChange={update("email")} error={fieldError("email")} placeholder="ama@example.com" required />
        <FormField label="Phone number" type="tel" value={form.phone} onChange={update("phone")} error={fieldError("phone")} placeholder="0244000000" required />
        <FormField label="Password" type="password" value={form.password} onChange={update("password")} error={fieldError("password")} placeholder="••••••••" required />
        <FormField label="Confirm password" type="password" value={form.password_confirmation} onChange={update("password_confirmation")} placeholder="••••••••" required />

        <button
          type="submit"
          disabled={loading}
          className="w-full mt-2 py-2.5 rounded-lg bg-navy text-white font-medium hover:bg-navy-dim transition-colors disabled:opacity-60"
        >
          {loading ? "Creating account…" : "Create account"}
        </button>
      </form>

      <div className="flex items-center gap-3 my-5">
        <div className="flex-1 h-px bg-border" />
        <span className="text-text-faint text-xs">or sign up with</span>
        <div className="flex-1 h-px bg-border" />
      </div>

      <a
        href={GOOGLE_AUTH_URL}
        className="w-full flex items-center justify-center gap-3 py-2.5 rounded-lg border border-border bg-ink hover:bg-surface transition-colors text-sm font-medium text-text"
      >
        <GoogleIcon />
        Continue with Google
      </a>

      <p className="text-center text-sm text-text-muted mt-6">
        Already have an account?{" "}
        <Link to="/signin" className="text-amber hover:underline">Sign in</Link>
      </p>
    </AuthShell>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M17.64 9.205c0-.639-.057-1.252-.164-1.841H9v3.481h4.844a4.14 4.14 0 01-1.796 2.716v2.259h2.908c1.702-1.567 2.684-3.875 2.684-6.615z" fill="#4285F4"/>
      <path d="M9 18c2.43 0 4.467-.806 5.956-2.18l-2.908-2.259c-.806.54-1.837.86-3.048.86-2.344 0-4.328-1.584-5.036-3.711H.957v2.332A8.997 8.997 0 009 18z" fill="#34A853"/>
      <path d="M3.964 10.71A5.41 5.41 0 013.682 9c0-.593.102-1.17.282-1.71V4.958H.957A8.996 8.996 0 000 9c0 1.452.348 2.827.957 4.042l3.007-2.332z" fill="#FBBC05"/>
      <path d="M9 3.58c1.321 0 2.508.454 3.44 1.345l2.582-2.58C13.463.891 11.426 0 9 0A8.997 8.997 0 00.957 4.958L3.964 7.29C4.672 5.163 6.656 3.58 9 3.58z" fill="#EA4335"/>
    </svg>
  );
}
